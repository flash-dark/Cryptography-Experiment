#include "btree.h"
#include <mysql.h>
#include <string.h>

std::map<string, long long> update;
CNode *root = nullptr;
long long updateStart;
long long updateEnd;
int my_server;
extern "C" {
    //typedef double longlong;
    //插入
    bool MInsert_init(UDF_INIT* initid, UDF_ARGS* args, char* message);
    long long MInsert(UDF_INIT *initid, UDF_ARGS *args,char *is_null, char *error);
    //搜索
    bool MSearch_init(UDF_INIT *const initid, UDF_ARGS *const args,char *const message);
    long long MSearch(UDF_INIT *const initid, UDF_ARGS *const args,
                         char *const result, unsigned long *const length,
                         char *const is_null, char *const error);
    
    //更新
    bool MUpdate_init(UDF_INIT* initid, UDF_ARGS* args, char* message);
    long long MUpdate(UDF_INIT *initid, UDF_ARGS *args,char *is_null, char *error);
    //更新范围
    bool MStart_init(UDF_INIT* initid, UDF_ARGS* args, char* message);
    long long MStart(UDF_INIT *initid, UDF_ARGS *args,char *is_null, char *error);
    bool MEnd_init(UDF_INIT* initid, UDF_ARGS* args, char* message);
    long long MEnd(UDF_INIT *initid, UDF_ARGS *args,char *is_null, char *error);
}

static char *
getba(UDF_ARGS *const args, int i, double &len)
{
    len = args->lengths[i];
    return args->args[i];
}


/*插入*/
long long MInsert(UDF_INIT *initid, UDF_ARGS *args, char *is_null, char *error)
{
    double keyLen;
    char *const keyBytes = getba(args, 0, keyLen);
    const std::string cipher = std::string(keyBytes, keyLen);
    update.clear();
	updateStart = 100000000;
	updateEnd = -1;
    long long result = root->insert(cipher,0);
	if (root->getKeyNum() >= MAXNUM_KEY) {
		CInternalNode * new_root = new CInternalNode();
		new_root->setChild(0, root);
		new_root->setKeyValue(0, root->getKeyValue(0));
		new_root->setKeyNum(1);
		root->split(new_root, 0, 0);
		root = new_root;
	}

	return result;
}

bool MInsert_init(UDF_INIT *initid, UDF_ARGS *args, char *message)
{
    updateStart = 100000000;
	updateEnd = -1;
    update.clear();
    if (!root) {
        root = new CLeafNode();
        get_client_connnect(my_server);
    }
    return 0;
}



/*搜索*/
long long
MSearch(UDF_INIT *const initid, UDF_ARGS *const args,
                         char *const result, unsigned long *const length,
                         char *const is_null, char *const error)
{
    double keyLen;
    char *const keyBytes = getba(args, 0, keyLen);
    const std::string cipher = std::string(keyBytes, keyLen);
    return root->search(cipher, 0);
}
/*
bool MSearch_init(UDF_INIT* initid, UDF_ARGS* args, char* message)
{
    return 0;
}
*/
bool
MSearch_init(UDF_INIT *const initid, UDF_ARGS *const args,
                              char *const message)
{
    
    return 0;
}




long long MUpdate(UDF_INIT *initid, UDF_ARGS *args, char *is_null, char *error)
{
    double keyLen;
    char *const keyBytes = getba(args, 0, keyLen);
    const std::string cipher = std::string(keyBytes, keyLen);
    if (update.count(cipher) > 0) {
		return update[cipher];
	}
	return -1;
}

bool MUpdate_init(UDF_INIT *initid, UDF_ARGS *args, char *message)
{
    return 0;
}



long long MStart(UDF_INIT *initid, UDF_ARGS *args, char *is_null, char *error)
{
    return updateStart;
}

bool MStart_init(UDF_INIT *initid, UDF_ARGS *args, char *message)
{
    return 0;
}




long long MEnd(UDF_INIT *initid, UDF_ARGS *args, char *is_null, char *error)
{
    
    return updateEnd;
}

bool MEnd_init(UDF_INIT *initid, UDF_ARGS *args, char *message)
{
    return 0;
}
