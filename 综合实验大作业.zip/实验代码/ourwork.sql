drop table if exists example;
create table example (encoding bigint, ciphertext varchar(512));
drop procedure if exists pro_insert;
drop procedure if exists CreateRegainTable;
drop procedure if exists recover;
drop function if exists FHInsert;
drop function if exists FHSearch;
drop function if exists FHUpdate;
drop function if exists FHStart;
drop function if exists FHEnd;
create function FHInsert RETURNS INTEGER SONAME 'ope.so';
create function FHSearch RETURNS INTEGER SONAME 'ope.so';
create function FHUpdate RETURNS INTEGER SONAME 'ope.so';
create function FHStart RETURNS INTEGER SONAME 'ope.so';
create function FHEnd RETURNS INTEGER SONAME 'ope.so';
DELIMITER //
CREATE PROCEDURE pro_insert(IN pos INT, IN ct VARCHAR(512)) 
BEGIN 
DECLARE i BIGINT DEFAULT 0; 
SET i = FHInsert(pos, ct); 
INSERT INTO example VALUES (i, ct); 
IF i = 0 THEN 
UPDATE example 
SET encoding = FHUpdate(ciphertext) 
WHERE (encoding >= FHStart() AND encoding < FHEnd()) OR (encoding = 0); 
END IF; 
END //
DELIMITER ;
DELIMITER //
CREATE PROCEDURE CreateRegainTable()
BEGIN
DROP TABLE IF EXISTS regain;
CREATE TEMPORARY TABLE temp_table AS
SELECT encoding, ciphertext FROM example ORDER BY encoding;
CREATE TABLE regain AS
SELECT @rownum := @rownum + 1 AS pos, ciphertext
FROM (SELECT @rownum := -1) r, temp_table;
DROP TEMPORARY TABLE temp_table;
END //
DELIMITER ;
DELIMITER // 
CREATE PROCEDURE recover() 
BEGIN 
DECLARE done INT DEFAULT FALSE;
DECLARE r_pos BIGINT;
DECLARE r_ciphertext VARCHAR(512);
DECLARE cur CURSOR FOR SELECT pos, ciphertext FROM regain;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
DROP TABLE IF EXISTS example; 
create table example (encoding bigint, ciphertext varchar(512)); 
OPEN cur; 
read_loop: LOOP
FETCH cur INTO r_pos, r_ciphertext; IF done THEN LEAVE read_loop; END IF; CALL pro_insert(r_pos, r_ciphertext); END LOOP; CLOSE cur; 
END // 
DELIMITER ;
