import os
import sys


# 项目入口
def main():
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'OnlineVotingSystem.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "请安装Django所需模块！"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
