from django.urls import path
from . import views

# 登录模块路由
urlpatterns = [
    # 首页（登录）
    path('', views.login, name='login'),
    # 退出
    path('logout/', views.logout, name='logout'),
    # 修改密码
    path('password_edit/', views.password_edit, name='password_edit'),
    # 注册
    path('register/', views.register, name='register')
]
