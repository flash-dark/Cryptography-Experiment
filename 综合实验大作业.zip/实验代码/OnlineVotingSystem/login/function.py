from django.db import connection
from django.shortcuts import render
import hashlib


def register(request):
    if request.method == "GET":
        return render(request, 'login/register.html')

    if request.method == "POST":
        name = request.POST['name']
        pswd_1 = request.POST['pswd_1']
        pswd_2 = request.POST['pswd_2']

        if pswd_1 != pswd_2:
            msg = "密码不一致！"
            return render(request, "login/register.html", {"msg": msg})

        # 检查用户名是否已存在
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT COUNT(*) FROM user WHERE name = %s AND is_active = %s", [name, True])
                user_count = cursor.fetchone()[0]
        except Exception as e:
            print("register异常:", e)
            msg = "查询用户名是否存在时出错"
            return render(request, 'login/register.html', {"msg": msg})

        if user_count > 0:
            msg = "用户名已存在！"
            return render(request, 'login/register.html', {"msg": msg})

        # 哈希密码
        m = hashlib.md5()
        m.update(pswd_2.encode())
        pswd_m = m.hexdigest()

        # 插入新用户
        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO user (name, password, time, is_active) VALUES (%s, %s, NOW(), %s)",
                    [name, pswd_m, True]
                )
        except Exception as e:
            print("register_create_user:", e)
            msg = "注册失败！！"
            return render(request, 'login/register.html', {"msg": msg})

        msg = "注册成功！"
        return render(request, 'login/login.html', {"msg": msg})
