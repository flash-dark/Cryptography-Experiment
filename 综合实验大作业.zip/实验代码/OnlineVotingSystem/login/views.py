import hashlib
from django.http import HttpResponseRedirect
from django.shortcuts import render
from login.models import *
from django.db import connection

# 01用户登录
def login(request):
    if request.method == "GET":
        return render(request, 'login/login.html')
    elif request.method == "POST":
        name = request.POST['name']
        password = request.POST['pswd']
        # 哈希算法
        m = hashlib.md5()
        m.update(password.encode())
        pswd_m = m.hexdigest()
        try:
            user = User.objects.filter(name=name, password=pswd_m)
        except Exception as e:
            print("login:", e)
        if user:
            user = User.objects.get(name=name)
            request.session['name'] = user.name
            return HttpResponseRedirect('/user/')
        else:
            msg = "账号或密码错误！！！"
            return render(request, 'login/login.html', {"msg": msg})


# 02用户注册
def register(request):
    if request.method == "GET":
        return render(request, 'login/register.html')

    if request.method == "POST":
        name = request.POST['name']
        pswd_1 = request.POST['pswd_1']
        pswd_2 = request.POST['pswd_2']

        if pswd_1 != pswd_2:
            msg = "密码不一致！"
            return render(request, "login/register.html", {"msg": msg})

        # 检查用户名是否已存在
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT COUNT(*) FROM user WHERE name = %s AND is_active = %s", [name, True])
                user_count = cursor.fetchone()[0]
        except Exception as e:
            print("register异常:", e)
            msg = "查询用户名是否存在时出错"
            return render(request, 'login/register.html', {"msg": msg})

        if user_count > 0:
            msg = "用户名已存在！"
            return render(request, 'login/register.html', {"msg": msg})

        # 哈希密码
        m = hashlib.md5()
        m.update(pswd_2.encode())
        pswd_m = m.hexdigest()

        # 插入新用户
        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO user (name, password, time, is_active) VALUES (%s, %s, NOW(), %s)",
                    [name, pswd_m, True]
                )
        except Exception as e:
            print("register_create_user:", e)
            msg = "注册失败！！"
            return render(request, 'login/register.html', {"msg": msg})

        msg = "注册成功！"
        return render(request, 'login/login.html', {"msg": msg})

# 03用户退出
def logout(request):
    if 'name' in request.session:
        del request.session['name']
    return HttpResponseRedirect('/')


# 04用户修改密码
def password_edit(request):
    name = request.session.get('name')
    try:
        user = User.objects.filter(name=name)
    except Exception as e:
        print(e)
    if request.method == 'GET':
        return render(request, 'login/password_edit.html')
    if request.method == 'POST':
        pswd1 = request.POST['pswd1']
        pswd2 = request.POST['pswd2']
        # 哈希算法
        m = hashlib.md5()
        m.update(pswd1.encode())
        pswd1 = m.hexdigest()
        if pswd1 == user.get().pswd:
            # 哈希算法
            m = hashlib.md5()
            m.update(pswd2.encode())
            pswd2 = m.hexdigest()
            user.update(password=pswd2)
            return HttpResponseRedirect('/logout/')
        else:
            msg = "密码错误"
            return render(request, 'login/password_edit.html', {"msg": msg})
