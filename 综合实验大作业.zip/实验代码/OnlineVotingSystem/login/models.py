from django.db import models
from django.utils.safestring import mark_safe


# 创建模型类
# 01用户类
class User(models.Model):
    id = models.AutoField(verbose_name="编号", primary_key=True)
    name = models.CharField(verbose_name="用户名", max_length=32, default='')
    password = models.CharField(verbose_name="密码", max_length=32, default='')
    time = models.DateTimeField(verbose_name="创建时间", auto_now_add=True)
    is_active = models.BooleanField('是否活跃', default=True)

    def __str__(self):
        return self.name

    class Meta:
        # 数据库列表名
        db_table = 'user'
        # 后台管理名
        verbose_name_plural = '用户列表'


# 02投票文件类
class Media(models.Model):
    id = models.AutoField(verbose_name="编号", primary_key=True)
    title = models.CharField(verbose_name="题目", max_length=32, default='')
    user = models.ForeignKey(verbose_name="用户", to='User', on_delete=models.CASCADE)
    photo = models.ImageField(verbose_name="图片", upload_to='user/photo/', default='暂无')
    synopsis = models.TextField(verbose_name="简介", default='暂无')
    time = models.DateTimeField(verbose_name="创建时间", auto_now_add=True)
    vote = models.IntegerField(verbose_name="点赞数", default=0)
    is_active = models.BooleanField('是否活跃', default=True)

    def __str__(self):
        return self.title

    def admin_sample(self):
        # django从view向template传递HTML字符串的时候，django默认不渲染此HTML，
        # 原因是为了防止这段字符串里面有恶意攻击的代码。
        return mark_safe('<img src="/media/%s" height="90" width="90" />' % (self.photo,))

    admin_sample.short_description = 'Sample'
    admin_sample.allow_tags = True

    class Meta:
        # 数据库列表名
        db_table = 'media'
        # 后台管理名
        verbose_name_plural = '投票管理'


# 03投票记录类
class MyVote(models.Model):
    id = models.AutoField(verbose_name="编号", primary_key=True)
    media = models.ForeignKey(verbose_name="资源", to='Media', on_delete=models.CASCADE)
    user = models.ForeignKey(verbose_name="用户", to='User', on_delete=models.CASCADE)
    time = models.DateTimeField(verbose_name="投票时间", auto_now=True)
    is_active = models.BooleanField('是否活跃', default=True)

    class Meta:
        # 数据库列表名
        db_table = 'vote'
        # 后台管理名
        verbose_name_plural = '用户投票'
