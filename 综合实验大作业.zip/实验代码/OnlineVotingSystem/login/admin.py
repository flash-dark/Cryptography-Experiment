from django.contrib import admin
from login.models import *

# 配置后台管理界面
# 标题显示设置
admin.site.site_title = "在线投票后台管理系统"
admin.site.site_header = "在线投票后台管理系统"
admin.site.index_title = "在线投票后台管理系统"


# 用户管理
class UserManager(admin.ModelAdmin):
    # 列表页显示那些字段
    list_display = ['id', 'name', 'password', 'time', 'is_active']


# 多媒体文件管理
class MediaManager(admin.ModelAdmin):
    list_display = ['id', 'title', 'user', 'synopsis', 'time', 'vote', 'is_active', 'admin_sample']


# 用户投票
class MyVoteManager(admin.ModelAdmin):
    # 列表页显示那些字段
    list_display = ['id', 'time', 'user', 'media']


# 注册实体类
admin.site.register(MyVote, MyVoteManager)
admin.site.register(Media, MediaManager)
admin.site.register(User, UserManager)
