import re
from django.shortcuts import redirect
from django.urls import reverse  # 反向解析重定向


# 自定义中间件(登录验证跳转)
class SimpleMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        path = request.path
        # 允许后台不登录情况下访问的路径
        urllist = ['/', '/logout/', '/login/', '/register/']
        if re.match(r'^/user/', path) and (path not in urllist):
            # 重定向到登录页
            if 'name' not in request.session:
                return redirect(reverse("login"))
        response = self.get_response(request)
        return response
