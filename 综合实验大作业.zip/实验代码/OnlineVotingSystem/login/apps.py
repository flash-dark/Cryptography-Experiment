from django.apps import AppConfig


class LoginConfig(AppConfig):
    name = 'login'
    verbose_name = '在线投票系统用户管理'
    verbose_name_plural = verbose_name
