from django.conf import settings
from django.contrib import admin
from django.urls import path, include
from django.urls import re_path
from django.views.static import serve

# 主路由
urlpatterns = [
    path('admin/', admin.site.urls, name="admin"),
    path('', include('login.urls')),
    path('user/', include('user.urls')),

]
if settings.DEBUG:
    urlpatterns += [
        re_path(r'^media/(?P<path>.*)$', serve, {
            'document_root': settings.MEDIA_ROOT,
        }),
    ]
