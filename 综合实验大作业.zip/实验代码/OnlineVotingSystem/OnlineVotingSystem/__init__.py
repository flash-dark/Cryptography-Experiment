# 配置数据库链接模块
import pymysql
pymysql.install_as_MySQLdb()
