from django.db.models import F
from django.shortcuts import render, HttpResponseRedirect
from django.utils import timezone
from login.models import *
from django.shortcuts import render
from django.db import connection


# 01跳转首页
def index(request):
    media = Media.objects.filter(is_active=True)
    return render(request, 'user/index.html', {"mm": media})


# 02添加媒体投票信息
def media_add(request):
    if request.method == "GET":
        return render(request, 'user/media_add.html')
    if request.method == "POST":
        name = request.session.get('name')
        user = User.objects.get(name=name)
        title = request.POST['title']
        synopsis = request.POST['synopsis']
        photo = request.FILES.get('photo')
        media = Media.objects.create(user=user, title=title, synopsis=synopsis, photo=photo)
        return HttpResponseRedirect('/user/my_media/')


# 03投票
def vote(request, id):
    user = request.session.get('name')
    try:
        media = Media.objects.get(id=id, is_active=True)
        user = User.objects.get(name=user)
        myvote = MyVote.objects.filter(user=user, media=media)
    except Exception as e:
        print('user_vote:', e)
    if myvote:
        time = myvote.get(media=media)
        d1 = timezone.now()
        if time.time.day == d1.day:
            msg = "你今天已投票，明天再来！"
            return render(request, 'user/msg.html', {"msg": msg})
        else:
            time.vote = F("vote") + 1
            time.save()
            return HttpResponseRedirect('/user/')
    else:
        myvote = MyVote.objects.create(user=user, media=media)
        media.vote = F("vote") + 1
        media.save()
        return HttpResponseRedirect('/user/')


# 04我发布的投票信息
def my_media(request):
    user = request.session.get('name')
    try:
        user = User.objects.get(name=user)
        media = Media.objects.filter(user=user, is_active=True)
    except Exception as e:
        print('user_vote:', e)
    return render(request, 'user/my_media.html', {"media": media})


# 06修改投票信息
def media_edit(request, id):
    try:
        media = Media.objects.get(id=id, is_active=True)
    except Exception as e:
        print(e)
        msg = "没有此评价内容："
        return render(request, 'user/msg.html', {"msg": msg})
    if request.method == 'GET':
        return render(request, 'user/media_edit.html', {"media": media})
    elif request.method == 'POST':
        title = request.POST['title']
        synopsis = request.POST['synopsis']
        photo = request.FILES.get('photo')
        media.title = title
        media.synopsis = synopsis
        media.photo = photo
        media.save()
        return HttpResponseRedirect('/user/my_media/')


# 07删除投票细信息
def media_del(request, id):
    try:
        media = Media.objects.get(id=id, is_active=True)
    except Exception as e:
        print(e)
        msg = "没有此评价内容："
        return render(request, 'user/msg.html', {"msg": msg})
    media.is_active = False
    media.save()
    return HttpResponseRedirect('/user/my_media/')


# 08投票排名
def media_ranking(request):
    media = []
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT ciphertext FROM example WHERE encoding > FHSearch(-1) AND encoding < FHSearch(3)")
            media = cursor.fetchall()
    except Exception as e:
        print('user_vote:', e)
        media = []  # 在发生异常时，提供一个空的查询集

    return render(request, 'user/media_ranking.html', {"media": media})