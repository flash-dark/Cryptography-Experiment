from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('my_media/', views.my_media, name='my_media'),
    path('media_add/', views.media_add, name='media_add'),
    path('media_edit/<int:id>/', views.media_edit, name='media_edit'),
    path('media_del/<int:id>/', views.media_del, name='media_del'),
    path('media_ranking/', views.media_ranking, name='media_ranking'),
    path('Vote/<int:id>/', views.vote, name='vote')
]
