#pragma once
#ifndef BPLUS_NODE
#define BPLUS_NODE
#include <vector>
#include <string.h>
#include <ctime>
#include <fstream>
#include <algorithm>
#include <map>
#include "socket.h"
#include <iostream>
#include <fstream>
using namespace std;

enum NODE_TYPE { INTERNAL, LEAF };
enum SIBLING_DIRECTION { LEFT, RIGHT };
const int ORDER = 4;
const int MINNUM_KEY = ORDER;
const int MAXNUM_KEY = 2 * ORDER;
extern std::map<string, long long> update;
extern long long updateStart;
extern long long updateEnd;
extern int my_server;

class CNode {
public:
    CNode();
    virtual ~CNode();
    /*node function*/
    NODE_TYPE getType() const { return m_Type; }
    void setType(NODE_TYPE type) { m_Type = type; }

    int getKeyNum() const { return m_KeyNum; }
    void setKeyNum(int n) { m_KeyNum = n; }
    
    std::string getKeyValue(int i) { return m_KeyValues[i]; }
    void setKeyValue(int i, std::string key) { m_KeyValues[i] = key; }
    int getKeyIndex(std::string key);

    void setParent(CNode* par) { this->parent = par; }
    CNode* getParent() { return this->parent; }

    int getPrefix() { return this->prefix; }
    void setPrefix(int index);
    /*node function for everybody*/
    virtual void split(CNode* parentNode, int childIndex, int parent) = 0;
    virtual long long insert(std::string key, int parent) = 0;
    virtual void clear() = 0;
    virtual void traverse(int parent) = 0;
    virtual long long search(std::string key, int parent) = 0;
    virtual void setUpdate(int index, int parent) = 0;
protected:
    NODE_TYPE m_Type;
    int m_KeyNum;
    std::string m_KeyValues[MAXNUM_KEY];
    int prefix;
    CNode *parent;
};

// internal ndoe
class CInternalNode : public CNode {
public:
    CInternalNode();
    ~CInternalNode();
    /*node function*/
    CNode* getChild(int i) { return m_Childs[i]; }
    void setChild(int i, CNode* child);
    void insert_node(int childIndex, std::string key, CNode* childNode, int parent);

    /*node function for everybody*/
    long long insert(std::string key, int parent) override;
    void split(CNode* parentNode, int childIndex, int parent) override;
    void clear() override;
    long long search(std::string key, int parent) override;
    void traverse(int parent) override;
    void setUpdate(int index, int parent) override;
private:
    CNode* m_Childs[MAXNUM_KEY];
};

// leaf node
class CLeafNode : public CNode {
public:
    CLeafNode();
    virtual ~CLeafNode();
    /*node function*/
    CLeafNode* getLeftSibling() { return m_LeftSibling; }
    void setLeftSibling(CLeafNode* node) { m_LeftSibling = node; }
    CLeafNode* getRightSibling() { return m_RightSibling; }
    void setRightSibling(CLeafNode* node) { m_RightSibling = node; }

    /*node function for everybody*/
    long long insert(std::string key, int parent) override;
    void split(CNode* parentNode, int childIndex, int parent) override;
    void clear() override;
    void traverse(int parent) override;
    long long search(std::string key, int parent) override;
    void setUpdate(int index, int parent) override;
private:
    CLeafNode* m_LeftSibling;
    CLeafNode* m_RightSibling;
    long long origin_encoding[MAXNUM_KEY];
};
#endif

bool compare(string cipher1, string cipher2) {

    string connect_cipher = cipher1 + "$$" + cipher2;
    int action = get_action(connect_cipher.c_str(), my_server);
    return action;

}

int compare_list(vector<string> cipher_list) {
	// ofstream out("logmope.txt",ios::app);
	// out<<"compare list"<<"\n";
	string connect_cipher = cipher_list[0];
	for (int i = 1; i < cipher_list.size(); i++) {
		connect_cipher = connect_cipher + "$$" + cipher_list[i];
	}
    // out<<connect_cipher<<"\n";
	
	string action = get_action_string(connect_cipher.c_str(), my_server);
    // out<<action<<"\n";
    // out.close();
	return atoi(action.c_str());

}

// CNode
CNode::CNode() {
    this->setType(LEAF);
    this->setKeyNum(0);
    this->setPrefix(0);
}

CNode::~CNode() {
    setKeyNum(0);
}

int CNode::getKeyIndex(std::string key)
{
    vector<string> compare_vector;
    int size = this->getKeyNum();
    for (int i = 0; i < size; i++) {
       compare_vector.push_back(this->m_KeyValues[i]);
    }
    compare_vector.push_back(key);

    return compare_list(compare_vector);
}


void CNode::setPrefix(int index) {
    this->prefix = index;
    
}

// CInternalNode
CInternalNode::CInternalNode() :CNode() {
    setType(INTERNAL);
}

CInternalNode::~CInternalNode() {

}

void CInternalNode::clear() {
    for (int i = 0; i <= m_KeyNum; ++i)
    {
        m_Childs[i]->clear();
        delete m_Childs[i];
        m_Childs[i] = NULL;
    }
}

void CInternalNode::setChild(int i, CNode* child) {
    this->m_Childs[i] = child;
    child->setPrefix(i);
    child->setParent(this);
}

void CInternalNode::split(CNode* parentNode, int childIndex, int parent)
{
    CInternalNode* newNode = new CInternalNode();
    newNode->setKeyNum(MINNUM_KEY);
    int i;
    for (i = 0; i < MINNUM_KEY; ++i)
    {
        newNode->setKeyValue(i, m_KeyValues[i + MINNUM_KEY]);
    }
    for (i = 0; i < MINNUM_KEY; ++i)
    {
        newNode->setChild(i, m_Childs[i + MINNUM_KEY]);
    }
    this->setKeyNum(MINNUM_KEY);
    newNode->setKeyNum(MINNUM_KEY);
    ((CInternalNode*)parentNode)->insert_node(childIndex + 1, newNode->getKeyValue(0), newNode, parent);
}

void CInternalNode::insert_node(int childIndex, std::string key, CNode* childNode, int parent) {
    childNode->setParent(this);
    for (int i = getKeyNum(); i > childIndex; --i) {
        this->setChild(i, this->m_Childs[i - 1]);
        this->setKeyValue(i, this->m_KeyValues[i - 1]);

    }
    this->setChild(childIndex, childNode);
    this->setKeyValue(childIndex, key);
    this->setKeyNum(m_KeyNum + 1);
    this->setUpdate(childIndex, parent);
}

long long CInternalNode::insert(std::string key, int parent) {
    // 找到子结点
    // ofstream out("logmope.txt",ios::app);
	// out<<"enter insert"<<"\n";
	// out.close();
    int keyIndex = this->getKeyIndex(key);
    if(keyIndex >= 1) keyIndex = keyIndex - 1;
    CNode* childNode = this->getChild(keyIndex);
    long long result = childNode->insert(key, parent* MAXNUM_KEY + this->getPrefix());
    if (childNode->getKeyNum() >= MAXNUM_KEY)  // 子结点已满，需进行分裂
    {
        childNode->split(this, keyIndex, parent);
    }
    this->setKeyValue(keyIndex, childNode->getKeyValue(0));
    // ofstream out1("logmope.txt",ios::app);
	// out1<<"out insert"<<"\n";
	// out1.close();
    return result;
}

long long CInternalNode::search(std::string key, int parent) {
    // 找到子结点
    int keyIndex = this->getKeyIndex(key);
    if(keyIndex >= 1) keyIndex = keyIndex - 1;
    CNode* childNode = this->getChild(keyIndex);
    long long result = childNode->search(key, parent* MAXNUM_KEY + this->getPrefix());
    return result;
}

void CInternalNode::setUpdate(int index,int parent) {
    for (int i = index; i < m_KeyNum; i++) {
        m_Childs[i]->setUpdate(0, parent*MAXNUM_KEY + this->getPrefix());
    }

}


void CInternalNode::traverse(int parent) {
    for (int i = 0; i < m_KeyNum; i++) {
        this->m_Childs[i]->traverse(parent*MAXNUM_KEY + this->getPrefix());
    }
}
// CLeafNode
CLeafNode::CLeafNode() :CNode() {
    setType(LEAF);
    setLeftSibling(NULL);
    setRightSibling(NULL);
}

CLeafNode::~CLeafNode() {

}

void CLeafNode::clear()
{

}

long long CLeafNode::insert(std::string key, int parent) {
    // ofstream out("logmope.txt",ios::app);
	// out<<"enter insert"<<"\n";
	// out.close();
    int index = 0;
    if (this->m_KeyNum > 0) {
        index = this->getKeyIndex(key);
    }
    for(int i = m_KeyNum - 1; i >= index; i --) {
        this->origin_encoding[i + 1] = this->origin_encoding[i];
        this->m_KeyValues[i + 1] = this->m_KeyValues[i];
    }

    this->setKeyValue(index, key);
    this->setKeyNum(m_KeyNum + 1);
    update.clear();
    long long result = parent * MAXNUM_KEY* MAXNUM_KEY + this->getPrefix() * MAXNUM_KEY + index;
    this->origin_encoding[index] = result;
    this->setUpdate(index, parent);
    // ofstream out1("logmope.txt",ios::app);
	// out1<<"out insert"<<"\n";
	// out1.close();
    return result;
}
void CLeafNode::split(CNode* parentNode, int childIndex,int parent)
{
    CLeafNode* newNode = new CLeafNode();
    this->setKeyNum(MINNUM_KEY);
    newNode->setKeyNum(MINNUM_KEY);
    newNode->setRightSibling(this->getRightSibling());
    if (this->m_RightSibling) {
        this->getRightSibling()->setLeftSibling(newNode);
    }
    this->setRightSibling(newNode);
    newNode->setLeftSibling(this);
    for (int i = 0; i < MINNUM_KEY; ++i) {
        newNode->setKeyValue(i, m_KeyValues[i + MINNUM_KEY]);
        newNode->origin_encoding[i] = this->origin_encoding[i + MINNUM_KEY];
    }
    ((CInternalNode*)parentNode)->insert_node(childIndex + 1, m_KeyValues[MINNUM_KEY], newNode, parent);
}

void CLeafNode::setUpdate(int index, int parent) {
    int par_prefix = parent * MAXNUM_KEY + this->getPrefix();
    for (int i = index; i < m_KeyNum; i++) {
        long long encoding = par_prefix * MAXNUM_KEY + i;
        std::string update_cipher = this->m_KeyValues[i];
        std::map<string, long long>::iterator it = update.find(update_cipher);
        if (update.count(update_cipher) > 0) {
            update.erase(it);
        } else {
            updateStart = min(updateStart,this->origin_encoding[i]);
            updateEnd = max(updateEnd,this->origin_encoding[i]);
        }
        // printf("update recoding %f\n", this->origin_encoding[i]);
        this->origin_encoding[i] = encoding;
        update.insert(std::pair<string, long long>(update_cipher, encoding));
    }

}

long long CLeafNode::search(std::string key, int parent) {
    // 找到子结点
    int keyIndex = this->getKeyIndex(key);
    return this->origin_encoding[keyIndex];
}
void CLeafNode::traverse(int parent) {
    int parent_leaf = parent * MAXNUM_KEY + this->getPrefix();
    ofstream out("lidongjie.txt",ios::app);
    for (int i = 0; i < m_KeyNum; i++) {
        out<<this->m_KeyValues[i]<<" "<<parent_leaf * MAXNUM_KEY +i<<"\n";
    }
    out.close();
}