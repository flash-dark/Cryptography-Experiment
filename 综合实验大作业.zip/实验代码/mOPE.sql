drop table if exists example;
create table example (encoding bigint, ciphertext varchar(512));
drop procedure if exists pro_Minsert;
drop function if exists MInsert;
drop function if exists MSearch;
drop function if exists MUpdate;
drop function if exists MStart;
drop function if exists MEnd;
create function MInsert RETURNS INTEGER SONAME 'mope.so';
create function MSearch RETURNS INTEGER SONAME 'mope.so';
create function MUpdate RETURNS INTEGER SONAME 'mope.so';
create function MStart RETURNS INTEGER SONAME 'mope.so';
create function MEnd RETURNS INTEGER SONAME 'mope.so';
DELIMITER //
create procedure pro_Minsert(IN ct varchar(512)) 
BEGIN 
DECLARE i BIGINT default 0; 
SET i = MInsert(ct); 
insert into example values (i, ct); 
SET i = MEnd(); 
update example set encoding = MUpdate(ciphertext) where encoding >= MStart() and encoding <= MEnd(); END //
DELIMITER ;