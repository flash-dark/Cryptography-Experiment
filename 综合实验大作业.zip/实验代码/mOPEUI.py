import tkinter as tk
from tkinter import messagebox
import pymysql
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from os import urandom, makedirs
import base64
import time
from tkinter import simpledialog

db_host='192.168.174.131'
db_password='NKUmysql12345!'
db_test='server2'

def encrypt_aes_cbc(key, plaintext):
    iv = urandom(16)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    padder = padding.PKCS7(algorithms.AES.block_size).padder()
    padded_data = padder.update(plaintext) + padder.finalize()
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()
    encoded_ciphertext = base64.b64encode(ciphertext).decode('utf-8')
    encoded_iv = base64.b64encode(iv).decode('utf-8')
    return f"{encoded_ciphertext}||{encoded_iv}"

def decrypt_aes_cbc(key, ciphertext, iv):
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    decrypted_padded_data = decryptor.update(ciphertext) + decryptor.finalize()
    unpadder = padding.PKCS7(algorithms.AES.block_size).unpadder()
    decrypted_data = unpadder.update(decrypted_padded_data) + unpadder.finalize()
    return decrypted_data

def setup_server_database():
    try:
        conn = pymysql.connect(host=db_host, user='root', password=db_password, database=db_test, charset='utf8')
        cursor = conn.cursor()
        sql_statements = [
            "DROP TABLE IF EXISTS codingtree;",
            "CREATE TABLE codingtree (encoding BIGINT, ciphertext VARCHAR(512));",
            "DROP PROCEDURE IF EXISTS pro_insert;",
            "DROP PROCEDURE IF EXISTS CreateRegainTable;",
            "DROP PROCEDURE IF EXISTS recover;",
            "DROP FUNCTION IF EXISTS MInsert;",
            "DROP FUNCTION IF EXISTS MSearch;",
            "DROP FUNCTION IF EXISTS MUpdate;",
            "DROP FUNCTION IF EXISTS MStart;",
            "DROP FUNCTION IF EXISTS MEnd;",
            "CREATE FUNCTION MInsert RETURNS INTEGER SONAME 'mope.so';",
            "CREATE FUNCTION MSearch RETURNS INTEGER SONAME 'mope.so';",
            "CREATE FUNCTION MUpdate RETURNS INTEGER SONAME 'mope.so';",
            "CREATE FUNCTION MStart RETURNS INTEGER SONAME 'mope.so';",
            "CREATE FUNCTION MEnd RETURNS INTEGER SONAME 'mope.so';"
        ]
        for statement in sql_statements:
            cursor.execute(statement)
        conn.commit()

        # 定义 pro_insert 存储过程
        procedure_pro_insert = """
        CREATE PROCEDURE pro_insert(IN ct VARCHAR(512))
        BEGIN
            DECLARE i BIGINT DEFAULT 0;
            SET i = MInsert(ct);
            INSERT INTO codingtree VALUES (i, ct);
            SET i = MEnd();
            update codingtree set encoding = MUpdate(ciphertext) where encoding >= MStart() and encoding <= MEnd();
        END
        """
        cursor.execute(procedure_pro_insert)
        conn.commit()

        # 定义 CreateRegainTable 存储过程
        procedure_create_regain_table = """
        CREATE PROCEDURE CreateRegainTable()
        BEGIN
            DROP TABLE IF EXISTS regain;
            CREATE TEMPORARY TABLE temp_table AS
            SELECT encoding, ciphertext FROM codingtree ORDER BY encoding;
            CREATE TABLE regain AS
            SELECT @rownum := @rownum + 1 AS pos, ciphertext
            FROM (SELECT @rownum := -1) r, temp_table;
            DROP TEMPORARY TABLE temp_table;
        END
        """
        cursor.execute(procedure_create_regain_table)
        conn.commit()

        # 定义 recover 存储过程
        procedure_recover = """
        CREATE PROCEDURE recover()
        BEGIN
            DECLARE done INT DEFAULT FALSE;
            DECLARE r_pos BIGINT;
            DECLARE r_ciphertext VARCHAR(512);
            DECLARE cur CURSOR FOR SELECT pos, ciphertext FROM regain;
            DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
            DROP TABLE IF EXISTS codingtree;
            CREATE TABLE codingtree (encoding BIGINT, ciphertext VARCHAR(512));
            OPEN cur;
            read_loop: LOOP
                FETCH cur INTO r_pos, r_ciphertext;
                IF done THEN
                    LEAVE read_loop;
                END IF;
                CALL pro_insert(r_ciphertext);
            END LOOP;
            CLOSE cur;
        END
        """
        cursor.execute(procedure_recover)
        conn.commit()

        cursor.close()
        conn.close()
        messagebox.showinfo("完成", "Server 数据库已设置")
    except Exception as e:
        messagebox.showerror("错误", str(e))

def encrypt_and_transfer():
    try:
        # 连接到 server 数据库
        server_conn = pymysql.connect(host=db_host, user='root', password=db_password, database=db_test, charset='utf8')
        server_cursor = server_conn.cursor()

        # 读取 local.txt 文件中的数据
        with open('ciscn/localtable.txt', 'r') as file:
            lines = file.readlines()

        key = b'your_secret_key_'  # 16, 24, or 32 bytes long key for AES

        # 开始计时
        start_time = time.time()

        # 加密数据并调用存储过程 pro_insert
        for line in lines:
            plaintext, count = line.strip().split()
            count = int(count)

            for _ in range(count):
                encrypted_data = encrypt_aes_cbc(key, plaintext.encode())
                server_cursor.execute('CALL pro_insert(%s)', (encrypted_data,))

        # 提交事务
        server_conn.commit()

        # 结束计时
        end_time = time.time()

        # 计算并输出所用时间
        elapsed_time = end_time - start_time

        # 调用存储过程 CreateRegainTable
        server_cursor.execute('CALL CreateRegainTable()')
        server_conn.commit()

        # 关闭 server 数据库连接
        server_cursor.close()
        server_conn.close()

        messagebox.showinfo("完成", f"数据加密并传输完成，耗时: {elapsed_time:.2f} 秒")
    except Exception as e:
        messagebox.showerror("错误", str(e))

def query_and_save():
    try:
        makedirs('ciscn', exist_ok=True)
        server_conn = pymysql.connect(host=db_host, user='root', password=db_password, database=db_test, charset='utf8')
        server_cursor = server_conn.cursor()

        # 使用 tkinter 的简单输入对话框获取 pos1 和 pos2
        root = tk.Tk()
        root.withdraw()  # 隐藏主窗口
        # 设置窗口始终在最上面
        root.attributes('-topmost', True)
        pos1 = tk.simpledialog.askinteger("", "请输入 pos1:")
        root.attributes('-topmost', True)
        pos2 = tk.simpledialog.askinteger("", "请输入 pos2:")
        root.destroy()

        start_time = time.time()
        query = """
        SELECT ciphertext 
        FROM codingtree 
        WHERE encoding > MSearch(%s) AND encoding < MSearch(%s);
        """
        server_cursor.execute(query, (pos1, pos2))
        results = server_cursor.fetchall()
        end_time = time.time()
        elapsed_time = end_time - start_time
        with open('ciscn/search_ct.txt', 'w', encoding='utf-8') as file:
            for row in results:
                file.write(f"{row[0]}\n")
        server_cursor.close()
        server_conn.close()
        messagebox.showinfo("完成", f"查询完成并已保存结果，耗时: {elapsed_time:.2f} 秒")
    except Exception as e:
        messagebox.showerror("错误", str(e))

def decrypt_data():
    try:
        key = b'your_secret_key_'
        input_file = 'ciscn/search_ct.txt'
        output_file = 'ciscn/decrypted.txt'
        with open(input_file, 'r') as f, open(output_file, 'w') as out:
            lines = f.readlines()
            for line in lines:
                encoded_ciphertext, encoded_iv = line.strip().split('||')
                ciphertext = base64.b64decode(encoded_ciphertext)
                iv = base64.b64decode(encoded_iv)
                decrypted_data = decrypt_aes_cbc(key, ciphertext, iv)
                out.write(decrypted_data.decode('utf-8') + '\n')
        messagebox.showinfo("完成", "数据解密完成")
    except Exception as e:
        messagebox.showerror("错误", str(e))

def recover_encoding_tree():
    try:
        # 连接到 server 数据库
        server_conn = pymysql.connect(host=db_host, user='root', password=db_password, database=db_test, charset='utf8')
        server_cursor = server_conn.cursor()

        # 调用存储过程 recover
        server_cursor.execute('CALL recover()')
        server_conn.commit()

        # 关闭连接
        server_cursor.close()
        server_conn.close()

        messagebox.showinfo("完成", "编码树已恢复")
    except Exception as e:
        messagebox.showerror("错误", str(e))

def main():
    root = tk.Tk()
    root.title("   mope方案")
    root.geometry("600x300")  # 设置窗口大小

    # 创建按钮并设置不同的颜色
    tk.Button(root, text="配置 Server 数据库", command=setup_server_database, bg="lightgreen").pack(fill=tk.X, pady=5)
    tk.Button(root, text="加密-构建编码树", command=encrypt_and_transfer, bg="lightcoral").pack(fill=tk.X, pady=5)
    tk.Button(root, text="查询并保存结果", command=query_and_save, bg="lightgoldenrodyellow").pack(fill=tk.X, pady=5)
    tk.Button(root, text="解密数据", command=decrypt_data, bg="lightpink").pack(fill=tk.X, pady=5)
    tk.Button(root, text="恢复编码树", command=recover_encoding_tree, bg="lightblue").pack(fill=tk.X, pady=5)

    root.mainloop()

if __name__ == "__main__":
    main()