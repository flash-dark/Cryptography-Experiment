from collections import Counter
import random

def generate_sorted_integers(file_path, num_integers, int_range):
    # 生成随机整数列表
    integers = [random.randint(1, int_range) for _ in range(num_integers)]
    # 对整数列表进行排序
    integers.sort()
    # 写入文件
    with open(file_path, 'w') as file:
        for integer in integers:
            file.write(f"{integer}\n")

file_path = 'ciscn/plaintext.txt'
num_integers = 1000
int_range = 300
generate_sorted_integers(file_path, num_integers, int_range)

# 读取文件
with open('cicns/plaintext.txt', 'r') as file:
    data = file.read().split()

# 计数数据
counter = Counter(data)

# 写入新文件
with open('ciscn/localtable.txt', 'w') as output_file:
    for item, count in counter.items():
        output_file.write(f"{item} {count}\n")