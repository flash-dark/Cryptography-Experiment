#include "Node.h"
#include "postgres.h"
#include "fmgr.h"

#include <string.h>
#include <map>
#include <string>



std::map<std::string, long long> update;
Node *root = nullptr;
long long start_update = -1;
long long end_update = -1;

extern "C" {
    PG_MODULE_MAGIC;

    // 插入
    PG_FUNCTION_INFO_V1(FHInsert);
    PG_FUNCTION_INFO_V1(FHInsert_init);

    // 搜索
    PG_FUNCTION_INFO_V1(FHSearch);
    PG_FUNCTION_INFO_V1(FHSearch_init);

    // 更新
    PG_FUNCTION_INFO_V1(FHUpdate);
    PG_FUNCTION_INFO_V1(FHUpdate_init);

    // 更新范围
    PG_FUNCTION_INFO_V1(FHStart);
    PG_FUNCTION_INFO_V1(FHStart_init);
    PG_FUNCTION_INFO_V1(FHEnd);
    PG_FUNCTION_INFO_V1(FHEnd_init);
}

static char *
getba(FunctionCallInfo fcinfo, int i, double &len)
{
    len = VARSIZE_ANY_EXHDR(PG_GETARG_VARLENA_P(i));
    return VARDATA_ANY(PG_GETARG_VARLENA_P(i));
}

/* 插入 */
extern "C" Datum FHInsert(PG_FUNCTION_ARGS)
{    
    start_update = -1;
    end_update = -1;
    update.clear();
    if (root == nullptr) 
     {
        root_initial();
     }
    int pos = PG_GETARG_INT32(0);
    double keyLen;
    char *const keyBytes = getba(fcinfo, 1, keyLen);
    const std::string cipher = std::string(keyBytes, keyLen);
    long long start_update = -1;
    long long end_update = -1;
    update.clear();
    long long re = root->insert(pos, cipher);
    // long long re = (long long)keyLen;
    PG_RETURN_INT64(re);
}

extern "C" Datum FHInsert_init(PG_FUNCTION_ARGS)
{
    start_update = -1;
    end_update = -1;
    update.clear();
    if (root == nullptr) {
        root_initial();
    }
    PG_RETURN_BOOL(true);
}

/* 搜索 */
extern "C" Datum FHSearch(PG_FUNCTION_ARGS)
{
    int pos = PG_GETARG_INT32(0);
    if (pos == -1) PG_RETURN_INT64(0);
    PG_RETURN_INT64(root->search(pos));
}

extern "C" Datum FHSearch_init(PG_FUNCTION_ARGS)
{
    PG_RETURN_BOOL(true);
}

/* 更新 */
extern "C" Datum FHUpdate(PG_FUNCTION_ARGS)
{
    double keyLen;
    char *const keyBytes = getba(fcinfo, 0, keyLen);
    const std::string cipher = std::string(keyBytes, keyLen);
    long long update_code = get_update(cipher);
    PG_RETURN_INT64(update_code);
}

extern "C" Datum FHUpdate_init(PG_FUNCTION_ARGS)
{
    PG_RETURN_BOOL(true);
}

/* 更新范围 */
extern "C" Datum FHStart(PG_FUNCTION_ARGS)
{
    PG_RETURN_INT64(lower_bound());
}

extern "C" Datum FHStart_init(PG_FUNCTION_ARGS)
{
    PG_RETURN_BOOL(true);
}

extern "C" Datum FHEnd(PG_FUNCTION_ARGS)
{
    PG_RETURN_INT64(upper_bound());
}

extern "C" Datum FHEnd_init(PG_FUNCTION_ARGS)
{
    PG_RETURN_BOOL(true);
}

