#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<string>

#define MAXLINE 4096


void get_client_connnect(int&  my_server){
    struct sockaddr_in  servaddr;
    if((my_server = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        return ;
    }
    memset(&servaddr, 0, sizeof(servaddr)); //清空
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(5000);
    if(inet_pton(AF_INET, "127.0.0.1", &servaddr.sin_addr) <= 0){
        return ;
    }

    if(connect(my_server, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0){
        return ;
    }

}


int get_action(const char * code, int my_server){
    char  buff_res[4096]; 
    if(send(my_server, code, strlen(code), 0) < 0){
        return -1;
    } 
    int n;
    int re = -1;
    char result[] = "true";
    n = recv(my_server, buff_res, MAXLINE, 0); //接收信息
    buff_res[n] = '\0';
    if (strcmp(buff_res, result) == 0){ 
        re = 1;
    } 
    return re;
}

std::string get_action_string(const char * code, int my_server){
    char  buff_res[4096]; 
    if(send(my_server, code, strlen(code), 0) < 0){
        return "";
    } 
    int n;
    std::string re;
    n = recv(my_server, buff_res, MAXLINE, 0); //接收信息
    buff_res[n] = '\0';
    re = buff_res;
    return re;
}
