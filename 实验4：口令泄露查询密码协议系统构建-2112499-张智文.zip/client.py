import socket
import json
import base64
import binascii
import hashlib
from argon2.low_level import hash_secret_raw, Type
import mysql.connector
import time

def hash_user(username, password):
    # 固定盐值，确保长度至少为8字节
    salt=b'\xf4\xde7\xf1\r\xda\xa8\xee\xfaT\xf4\xdcev<\xbd'
    # Argon2参数
    time_cost = 2
    memory_cost = 102400
    parallelism = 8
    hash_len = 32
    argon2_type = Type.ID
    r=5
    p = 2**59 - 1  # 示例值，根据实际情况调整
    # 使用固定盐值计算用户名的哈希值
    username_hash_bytes = hash_secret_raw(
        secret=username.encode('utf-8'),
        salt=salt,
        time_cost=time_cost,
        memory_cost=memory_cost,
        parallelism=parallelism,
        hash_len=hash_len,
        type=argon2_type
    )
    # 将二进制数据转换为十六进制字符串
    username_hash_hex = binascii.hexlify(username_hash_bytes).decode('utf-8')

    # 使用固定盐值计算“用户名||password”的哈希值
    combined = (username + "||" + password).encode('utf-8')
    combined_hash_bytes = hash_secret_raw(
        secret=combined,
        salt=salt,
        time_cost=time_cost,
        memory_cost=memory_cost,
        parallelism=parallelism,
        hash_len=hash_len,
        type=argon2_type
    )
    # 将二进制数据转换为十六进制字符串
    combined_hash_hex = binascii.hexlify(combined_hash_bytes).decode('utf-8')

    # 使用SHA-256作为伪随机函数
    prf_result1 = hashlib.sha256(combined_hash_hex.encode()).hexdigest()
    # 将十六进制字符串转换为整数
    prf_result2 = int(prf_result1, 16)
    print(prf_result2)
    result = (prf_result2 * r) % p

    # 返回username_hash_hex的前4个16进制字符和prf_result
    return username_hash_hex[:4], result

def create_client(server_host, server_port, value1, value2):
    # 创建一个socket对象
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # 连接到服务器
    client_socket.connect((server_host, server_port))
    
    # 准备发送的数据，这里我们发送两个整数值
    message = f"{value1},{value2}"
    print("向服务器发送桶编号：",value1)
    print("向服务器发送x：",value2)
    client_socket.sendall(message.encode())
    
    # 首先接收y的值
    response = client_socket.recv(32768)
    y = int(response.decode())  # 假设y是整数形式
    print("接收到服务器发送的y：", y)

    r = 5  
    p = 2**59 - 1 
    
    x_1 = (y * pow(r, -1, p)) % p
    print("通过y计算出要在桶中查询的x：", x_1)

    # 接下来接收整张表的数据或“未泄露”消息
    response = client_socket.recv(32768)
    table_data = response.decode()

    # 检查是否收到“未泄露”消息
    if table_data == "未泄露":
        print("输入的口令未泄露")
    else:
        # 解析JSON格式的表数据
        try:
            table = json.loads(table_data)
            # 将x_1转换为字符串
            x_1_str = str(x_1)
            # 查找x_1是否存在于表中的enc_users列
            found = any(x_1_str == row['enc_users'] for row in table)
            if found:
                print("x在桶中，输入的口令是泄露的")
            else:
                print("输入的口令未泄露")
        except json.JSONDecodeError:
            print("Error decoding table data from server")
    
    # 关闭连接
    client_socket.close()

if __name__ == "__main__":
    start_time = time.time()

    HOST = '127.0.0.1'
    PORT = 5555
    
    username = input("输入username: ")
    password = input("输入password: ")
    bucket, x = hash_user(username, password)
    
    create_client(HOST, PORT, bucket, x)

    end_time = time.time()

    print(f"完成查询时间: {end_time - start_time} 秒")