import socket
import mysql.connector
import json

def calculate_y(x):
    # 计算x的3次方作为y
    k=3
    p = 2**59 - 1
    return (x * k) % p

def fetch_table_data(bucket):
    # 连接到MySQL数据库
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="123456",
            database="gpc_server"
        )
        cursor = conn.cursor(dictionary=True)
        
        table_name = f"bucket_{bucket}"
        # 执行查询，获取整张表的数据
        query = f"SELECT * FROM {table_name}"
        cursor.execute(query)
        result = cursor.fetchall()
        
        # 关闭数据库连接
        cursor.close()
        conn.close()
        
        # 将结果转换为JSON格式
        return json.dumps(result, default=str)  # 使用default=str处理datetime等非JSON序列化类型
    except mysql.connector.Error as err:
        print("未找到对应的桶")
        return "未泄露"

def server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('127.0.0.1', 5555))
    server_socket.listen(1)
    print("Server is listening...")
    
    while True:
        client_socket, addr = server_socket.accept()
        print(f"Connection from {addr}")
        
        # 接收客户端发送的数据
        data = client_socket.recv(32768).decode()
        bucket, x = data.split(',')
        print("收到客户端发送的桶编号：",bucket)
        print("收到客户端发送的x：",x)
        x = int(x)  # 确保x是整数
        
        # 计算y并发送给客户端
        y = calculate_y(x)
        print("计算y发送给客户端",y)
        client_socket.sendall(str(y).encode())
        
        # 获取bucket对应的表数据并发送给客户端
        table_data = fetch_table_data(bucket)
        client_socket.sendall(table_data.encode('utf-8'))
        print("已将对应编号的桶发送给客户端")
        
        # 关闭客户端连接
        client_socket.close()

if __name__ == "__main__":
    server()