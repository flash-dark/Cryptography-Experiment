#coding=utf-8

from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, G2, GT, pair
import hashlib

Hash1pre = hashlib.md5
def Hash1(w):
    hv = Hash1pre(str(w).encode('utf8')).hexdigest()
    print(hv)
    hv = group.hash(hv, type=G1)
    return hv

Hash2 = hashlib.sha256

def Setup(param_id='SS512'):
    group = PairingGroup(param_id)
    g = group.random(G1)
    alpha = group.random(ZR)
    sk = group.serialize(alpha)
    pk = [group.serialize(g), group.serialize(g ** alpha)]
    return [sk, pk]

def Enc(pk, w, param_id='SS512'):
    group = PairingGroup(param_id)
    g, h = group.deserialize(pk[0]), group.deserialize(pk[1])
    r = group.random(ZR)
    t = pair(Hash1(w), h ** r)
    c1 = g ** r
    c2 = t
    print(group.serialize(c2))
    return [group.serialize(c1), Hash2(group.serialize(c2)).hexdigest()]

def TdGen(sk, w, param_id='SS512'):
    group = PairingGroup(param_id)
    sk = group.deserialize(sk)
    td = Hash1(w) ** sk
    return group.serialize(td)

def Test(td, c, param_id='SS512'):
    group = PairingGroup(param_id)
    c1 = group.deserialize(c[0])
    c2 = c[1]
    print(c2)
    td = group.deserialize(td)
    return Hash2(group.serialize(pair(td, c1))).hexdigest() == c2


if __name__ == '__main__':
    param_id = 'SS512'
    [sk, pk] = Setup(param_id)

    group = PairingGroup(param_id)

    c = Enc(pk, "yes")
    td = TdGen(sk, "yes")
    assert(Test(td, c))
    td = TdGen(sk, "no")
    assert(not Test(td, c))
    c = Enc(pk, "Su*re")
    assert(not Test(td, c))
    c = Enc(pk, "no")
    assert(Test(td, c))

    c = Enc(pk, 9 ** 100)
    td = TdGen(sk, 9 ** 100)
    assert(Test(td, c))
    td = TdGen(sk, 9 ** 100 + 1)
    assert(not Test(td, c)) 